/*!
 test log:
 7/2/2021 test succeed!
 7/7/2021 test succeed with an Andriod app and with a hair dryer


    \file  main.c
    \brief USB CDC ACM device


    modified from a example project of GD32VF103(GigaDevice Semiconductor Inc)
    this project use SPI to get a temperature value from a BMP280 temperature module,
    and then use USB CDC to sent it to a host (PC or Android)

    chip:GD32VF103CBT6 ( or  GD32VF103VBT6)
    board:sipeed Longan Nano (you can also use GD32VF103V-EVAL-V1.0 board which has GD32VF103VBT6 on it.
    the linker is same. but the pinouts has a little difference)
*/



#include "drv_usb_hw.h"
#include "cdc_acm_core.h"
#include "bmp280.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DUMMY_BYTE       0x00
#define  SPI0_CS_LOW()        gpio_bit_reset(GPIOB, GPIO_PIN_0)  //use PB0 pin as the SPI0 chip select pin
#define  SPI0_CS_HIGH()       gpio_bit_set(GPIOB, GPIO_PIN_0)


extern uint8_t packet_sent, packet_receive;
extern uint32_t receive_length;

void spi_config(void);

//--start of bmp280 variables------
void bmp280_config(void);
void bmp280_get_data(void);
void delay_ms(uint32_t period_ms);
int8_t spi_reg_write(uint8_t cs, uint8_t reg_addr, uint8_t *reg_data, uint16_t length);
int8_t spi_reg_read(uint8_t cs, uint8_t reg_addr, uint8_t *reg_data, uint16_t length);
uint8_t spi_send_byte(uint8_t byte);
uint8_t spi_read_byte(void);

int8_t rslt;
struct bmp280_dev bmp;
struct bmp280_config conf;
struct bmp280_uncomp_data ucomp_data;
int32_t temp32;
double temp;

uint32_t pres32, pres64;
double pres;
//--end of bmp280 variables------

usb_core_driver USB_OTG_dev = 
{
    .dev = {
        .desc = {
            .dev_desc       = (uint8_t *)&device_descriptor,
            .config_desc    = (uint8_t *)&configuration_descriptor,
            .strings        = usbd_strings,
        }
    }
};


/*!
    \brief      main routine will construct a USB keyboard
    \param[in]  none
    \param[out] none
    \retval     none
*/
int main(void)
{

    eclic_global_interrupt_enable();	

    eclic_priority_group_set(ECLIC_PRIGROUP_LEVEL2_PRIO2);

    usb_rcu_config();

    usb_timer_init();

    usb_intr_config();

    usbd_init (&USB_OTG_dev, USB_CORE_ENUM_FS, &usbd_cdc_cb);


    //---start init SPI0--
    spi_config();

    //----init BMP280---
    bmp280_config();
	//bmp280_get_data();

    // check if USB device is enumerated successfully
    while (USBD_CONFIGURED != USB_OTG_dev.dev.cur_status) {
    }

    while (1) {
        if (USBD_CONFIGURED == USB_OTG_dev.dev.cur_status) {
            if (1 == packet_receive && 1 == packet_sent) {
                packet_sent = 0;
                // receive datas from the host when the last packet datas have sent to the host
                cdc_acm_data_receive(&USB_OTG_dev);
            } else {
                if (0 != receive_length) {
                    // get data from SPI0/bmp280
                	bmp280_get_data(); //--after this line, the temperature value will be in temp32 (32bits) and temp(64bits)

                    cdc_acm_data_send(&USB_OTG_dev, receive_length); //--original, I will compose the temp32 value into "usb_data_buffer_to_host" here
                    receive_length = 0;
                }
            }
        }

    }
}

void spi_config(void)
{
    spi_parameter_struct spi_init_struct;

    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_SPI0);

    /* SPI0_SCK(PA5), SPI0_MISO(PA6) and SPI0_MOSI(PA7) GPIO pin configuration */
    gpio_init(GPIOA, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_5 | GPIO_PIN_7);
    gpio_init(GPIOA, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, GPIO_PIN_6);
    /* SPI0_CS(Here I use PB0) GPIO pin configuration */
    gpio_init(GPIOB, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_0);

    /* chip select invalid*/
    SPI0_CS_HIGH();  //=gpio_bit_set(GPIOB, GPIO_PIN_0)


    /* SPI0 parameter config */
    spi_init_struct.trans_mode           = SPI_TRANSMODE_FULLDUPLEX;
    spi_init_struct.device_mode          = SPI_MASTER;
    spi_init_struct.frame_size           = SPI_FRAMESIZE_8BIT;
    spi_init_struct.clock_polarity_phase = SPI_CK_PL_LOW_PH_1EDGE;
    //--BMP280 use SPI mode �00� (CPOL = CPHA = �0�) and mode �11� (CPOL = CPHA = �1�)---page 28/49 bmp280.pdf---mzhu
    spi_init_struct.nss                  = SPI_NSS_SOFT;
    //when use soft mode on NSS pin. as document said that I can use spi_nss_internal_high(SPI0) and
    //spi_nss_internal_low(SPI0) to control the NSS pin high or low to satisfy the "burst read"--referenced to
    //"3.10 Data register shadowing" of BMP280.pdf . but I tried. the use spi_nss_internal_high(SPI0) and
    //use spi_nss_internal_high(SPI0) don't work.
    //so I can use a GPIO pin as CS to control slave chip
    spi_init_struct.prescale             = SPI_PSC_8;
    spi_init_struct.endian               = SPI_ENDIAN_MSB;
    //--then init SPI0 with above config--
    spi_init(SPI0, &spi_init_struct);

    /* enable SPI0 */
    spi_enable(SPI0);

}

void bmp280_config(void)
{

	    /* Map the delay function pointer with the function responsible for implementing the delay */
	    bmp.delay_ms = delay_ms;

	    /* Assign device I2C address based on the status of SDO pin (GND for PRIMARY(0x76) & VDD for SECONDARY(0x77)) */
	    //bmp.dev_id = BMP280_I2C_ADDR_PRIM;

	    /* Select the interface mode as I2C */
	    //bmp.intf = BMP280_I2C_INTF;

	    /* Map the I2C read & write function pointer with the functions responsible for I2C bus transfer */
	    //bmp.read = i2c_reg_read;
	    //bmp.write = i2c_reg_write;

	    /* To enable SPI interface: comment the above 4 lines and uncomment the below 4 lines */

	     bmp.dev_id = 0;
	     bmp.read = spi_reg_read;
	     bmp.write = spi_reg_write;
	     bmp.intf = BMP280_SPI_INTF;

	    rslt = bmp280_init(&bmp);
	    //print_rslt(" bmp280_init status", rslt);

	    /* Always read the current settings before writing, especially when
	     * all the configuration is not modified
	     */
	    rslt = bmp280_get_config(&conf, &bmp);
	    //print_rslt(" bmp280_get_config status", rslt);

	    /* configuring the temperature oversampling, filter coefficient and output data rate */
	    /* Overwrite the desired settings */
	    conf.filter = BMP280_FILTER_COEFF_2;

	    /* Temperature oversampling set at 4x */
	    conf.os_temp = BMP280_OS_4X;

	    /* Pressure over sampling none (disabling pressure measurement) */
	    conf.os_pres = BMP280_OS_NONE;

	    /* Setting the output data rate as 1HZ(1000ms) */
	    conf.odr = BMP280_ODR_1000_MS;
	    rslt = bmp280_set_config(&conf, &bmp);
	    //print_rslt(" bmp280_set_config status", rslt);

	    /* Always set the power mode after setting the configuration */
	    rslt = bmp280_set_power_mode(BMP280_NORMAL_MODE, &bmp);
	    //print_rslt(" bmp280_set_power_mode status", rslt);

}
void bmp280_get_data(void)
{

    // Reading the raw data from sensor
     rslt = bmp280_get_uncomp_data(&ucomp_data, &bmp);

	// Getting the 32 bit compensated temperature
	rslt = bmp280_get_comp_temp_32bit(&temp32, ucomp_data.uncomp_temp, &bmp);

	// Getting the compensated temperature as floating point value
	rslt = bmp280_get_comp_temp_double(&temp, ucomp_data.uncomp_temp, &bmp);
	//printf("UT: %ld, T32: %ld, T: %f \r\n", ucomp_data.uncomp_temp, temp32, temp);

	// Sleep time between measurements = BMP280_ODR_1000_MS
	//bmp.delay_ms(10);
}

/*!
 *  @brief Function that creates a mandatory delay required in some of the APIs such as "bmg250_soft_reset",
 *      "bmg250_set_foc", "bmg250_perform_self_test"  and so on.
 *
 *  @param[in] period_ms  : the required wait time in milliseconds.
 *  @return void.
 *
 */
void delay_ms(uint32_t count)
{
    /* Implement the delay routine according to the target machine */
    uint64_t start_mtime, delta_mtime;

    /* don't start measuruing until we see an mtime tick */
    uint64_t tmp = get_timer_value();

    do{
        start_mtime = get_timer_value();
    }while(start_mtime == tmp);

    do{
        delta_mtime = get_timer_value() - start_mtime;
    }while(delta_mtime <(SystemCoreClock/4000.0 *count));
}
/*!
 *  @brief Function for writing the sensor's registers through SPI bus.
 *
 *  @param[in] cs           : Chip select to enable the sensor.
 *  @param[in] reg_addr     : Register address.
 *  @param[in] reg_data : Pointer to the data buffer whose data has to be written.
 *  @param[in] length       : No of bytes to write.
 *
 *  @return Status of execution
 *  @retval 0 -> Success
 *  @retval >0 -> Failure Info
 *
 */
int8_t spi_reg_write(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len)
{

    /* Implement the SPI write routine according to the target machine. */


	int8_t rslt = 0; /* Return 0 for Success, non-zero for failure */
	uint8_t cnt = 0;
	SPI0_CS_LOW();    //---set CS(PB0) to low
    //spi_nss_internal_low(SPI0);
	delay_ms(10);  //must have some delay here. Tried. at least 10ms --mzhu
    spi_send_byte(reg_addr);
	do
	{
		spi_send_byte(reg_data[cnt]);
		cnt++;
	}while (len > cnt);
	delay_ms(2);
	SPI0_CS_HIGH();  //--set CS high--
	//spi_nss_internal_high(SPI0);
	return rslt;
}

/*!
 *  @brief Function for reading the sensor's registers through SPI bus.
 *
 *  @param[in] cs       : Chip select to enable the sensor.
 *  @param[in] reg_addr : Register address.
 *  @param[out] reg_data    : Pointer to the data buffer to store the read data.
 *  @param[in] length   : No of bytes to read.
 *
 *  @return Status of execution
 *  @retval 0 -> Success
 *  @retval >0 -> Failure Info
 *
 */
int8_t spi_reg_read(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len)
{

    /* Implement the SPI read routine according to the target machine. */

    int8_t rslt = 0; /* Return 0 for Success, non-zero for failure */
	int8_t cnt = 0;

	SPI0_CS_LOW();    //---set CS(PB0) to low
	//spi_nss_internal_low(SPI0);	//---it is not working
	delay_ms(10);  //must have some delay here. Tried. at least 10ms --mzhu
	spi_send_byte(reg_addr);
	do
	{
		*reg_data = (uint8_t)spi_read_byte();
		reg_data ++;
		cnt++;
	}while (len > cnt);

	delay_ms(2);
	SPI0_CS_HIGH(); //--set CS high--
	//spi_nss_internal_high(SPI0);
		//_delay_ms(10);
	return rslt;

}

/*!
    \brief      send a byte through the SPI interface and return the byte received from the SPI bus
    \param[in]  byte: byte to send
    \param[out] none
    \retval     the value of the received byte
*/
uint8_t spi_send_byte(uint8_t byte)
{
    //--in full-duplex master mode, in order to get the receive data you must put a data to SPI_DATA first ---mzhu
    /* loop while data register in not emplty */
    while (RESET == spi_i2s_flag_get(SPI0,SPI_FLAG_TBE));

    /* send byte through the SPI0 peripheral */
    spi_i2s_data_transmit(SPI0,byte);  //--put the data into SPI_DATA(transmit buffer) register, then the chip will move it to the shift register

    /* wait to receive a byte */
    while(RESET == spi_i2s_flag_get(SPI0,SPI_FLAG_RBNE));

    /* return the byte read from the SPI bus */
    return(spi_i2s_data_receive(SPI0)); //--get the data from SPI_DATA(also as receive register)

}

/*!
    \brief      read a byte from the SPI flash
    \param[in]  none
    \param[out] none
    \retval     byte read from the SPI flash
*/
uint8_t spi_read_byte(void)
{
    return(spi_send_byte(DUMMY_BYTE));
}
